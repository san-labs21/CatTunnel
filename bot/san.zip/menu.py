import telebot
import subprocess
import json
from telebot import types
import os
import shutil
import zipfile
import time
from threading import Thread
from create_trial_ssh import create_ssh, trial_ssh
from delete_ssh import delete_ssh, handle_confirmation
from renew_ssh import renew_ssh
from detail_ssh import detail_ssh
from create_vmess import create_vmess
from delete_vmess import delete_vmess, handle_confirmation_vmess
from renew_vmess import renew_vmess
from trial_vmess import trial_vmess
from detail_vmess import detail_vmess
from create_vless import create_vless
from delete_vless import delete_vless, delete_confirm_vless
from renew_vless import renew_vless
from detail_vless import detail_vless
from trial_vless import trial_vless
from create_trojan import create_trojan
from delete_trojan import delete_trojan, process_to_delete_trojan
from renew_trojan import renew_trojan
from detail_trojan import detail_trojan
from trial_trojan import trial_trojan
from status_service import send_status, reboot_system


# === Token Bot ===
TOKEN = 'token_tele'
bot = telebot.TeleBot(TOKEN)

# === Chat ID yang diizinkan mengakses bot ===
AUTHORIZED_CHAT_ID = chat_id  # Ganti dengan chat ID Anda

def bot_online():
    bot.send_message(AUTHORIZED_CHAT_ID, "✅ Bot Telah Online")

# === Fungsi untuk Jalankan Shell Command ===
def shell_exec(cmd):
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode('utf-8').strip()
        return output.split('\n')[0]  # Ambil hanya baris pertama
    except:
        return ""

# === Ambil Informasi Server ===
def get_server_info():
    os_pretty = shell_exec("grep -E '^PRETTY_NAME=' /etc/os-release | cut -d= -f2 | tr -d '\"'")
    ip = shell_exec("curl -s ifconfig.me")

    # Default values
    isp = 'Unknown'
    country = 'Unknown'
    city = 'Unknown'

    # Menggunakan hanya ip-api.com
    try:
        raw_data = shell_exec("curl -s http://ip-api.com/json/")
        if raw_data:
            data = json.loads(raw_data)
            if data.get('status') == 'success':
                isp = data.get('isp', isp)
                country = data.get('country', country)
                city = data.get('city', city)
    except:
        pass

    domain = shell_exec("cat /etc/xray/domain 2>/dev/null || echo 'Not Found'")
    version = shell_exec("cat /etc/xray/version 2>/dev/null || echo 'Not Found'")

    # Hitung jumlah akun
    vmess_count = shell_exec("grep -c '##' /etc/xray/config.json 2>/dev/null || echo 0")
    vless_count = shell_exec("grep -c '#?' /etc/xray/config.json 2>/dev/null || echo 0")
    trojan_count = shell_exec("grep -c '#!' /etc/xray/config.json 2>/dev/null || echo 0")
    ssh_count = shell_exec("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l")

    return {
        'os': os_pretty,
        'ip': ip,
        'isp': isp,
        'country': country,
        'city': city,
        'domain': domain,
        'version': version,
        'vmess': int(vmess_count) // 2 if vmess_count.isdigit() else 0,
        'vless': int(vless_count) // 2 if vless_count.isdigit() else 0,
        'trojan': int(trojan_count) // 2 if trojan_count.isdigit() else 0,
        'ssh': int(ssh_count) if ssh_count.isdigit() else 0,
    }

# === Handler untuk Perintah /start ===
@bot.message_handler(commands=['NAMA_SERVER'])
def send_welcome(message):
    if message.chat.id != AUTHORIZED_CHAT_ID:
        bot.reply_to(message, "❌ Anda tidak memiliki akses ke bot ini.")
        return

    info = get_server_info()

    # Format region
    region = info['country']
    if info['city'] != 'Unknown':
        region = f"{info['city']}, {info['country']}"

    status_text = f"""🖥️ *Server Information* 🖥️
─────────────────────
*OS System :* `{info['os']}`
*ISP :* `{info['isp']}`
*Region :* `{region}`
*IP :* `{info['ip']}`
*Domain :* `{info['domain']}`
*XRay Version :* `{info['version']}`

🔐 *Jumlah Akun Aktif* 🔐
*SSH* : `{info['ssh']}`
*Vmess* : `{info['vmess']}`
*Vless* : `{info['vless']}`
*Trojan* : `{info['trojan']}`
─────────────────────"""

    # Membuat markup inline keyboard
    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
    btn_ssh = telebot.types.InlineKeyboardButton("MENU SSH", callback_data='menu_ssh')
    btn_vmess = telebot.types.InlineKeyboardButton("MENU VMESS", callback_data='menu_vmess')
    btn_vless = telebot.types.InlineKeyboardButton("MENU VLESS", callback_data='menu_vless')
    btn_trojan = telebot.types.InlineKeyboardButton("MENU TROJAN", callback_data='menu_trojan')
    btn_lain = telebot.types.InlineKeyboardButton("MENU LAIN", callback_data='menu_lain')

    markup.add(btn_ssh, btn_vmess)
    markup.add(btn_vless, btn_trojan)
    markup.add(btn_lain)

    bot.send_message(message.chat.id, status_text, reply_markup=markup, parse_mode='Markdown')

# === Handler untuk Callback Inline Button ===
@bot.callback_query_handler(func=lambda call: True)
def handle_callback_query(call):
    if call.message.chat.id != AUTHORIZED_CHAT_ID:
        bot.answer_callback_query(call.id, "Anda tidak memiliki akses.")
        return

    data = call.data

    if data == 'menu_ssh':
        menu_ssh(call)
    elif data == 'menu_vmess':
        menu_vmess(call)
    elif data == 'menu_vless':
        menu_vless(call)
    elif data == 'menu_trojan':
        menu_trojan(call)
    elif data == 'menu_lain':
        menu_lain(call)
    elif data == 'menu_utama':
        menu_utama(call)        
    # === Bagian Qallbackquerry Fungsi Menu SSH ===
    elif data == 'create_ssh':
        create_ssh(bot, call.message)    
    elif data == 'trial_ssh':
        trial_ssh(bot, call.message)    
    elif call.data == "delete_ssh":
        delete_ssh(bot, call.message)
    elif call.data.startswith('confirm_yes_') or call.data.startswith('confirm_no_'):
        handle_confirmation(bot, call)
    elif call.data == "renew_ssh":
        renew_ssh(bot, call.message)
    elif call.data == "detail_ssh":
        detail_ssh(bot, call.message)
    # === Bagian Qallbackquerry Fungsi Menu VMESS ===
    elif data == 'create_vmess':
        create_vmess(bot, call.message)    
    elif call.data == "delete_vmess":
        delete_vmess(bot, call.message)
    elif call.data.startswith('confirm_delete_vmess') or call.data == "cancel_delete":
        handle_confirmation_vmess(bot, call)
    elif call.data == "renew_vmess":
        renew_vmess(bot, call.message)
    elif call.data == "trial_vmess":
        trial_vmess(bot, call.message)
    elif call.data == "detail_vmess":
        detail_vmess(bot, call.message)
    # === Bagian Qallbackquerry Fungsi Menu VLESS ===
    elif data == 'create_vless':
        create_vless(bot, call.message)    
    elif call.data == "delete_vless":
        delete_vless(bot, call.message)
    elif call.data.startswith('confirm_delete_vless') or call.data == "cancel_delete":
        delete_confirm_vless(bot, call)
    elif call.data == "renew_vless":
        renew_vless(bot, call.message)
    elif call.data == "detail_vless":
        detail_vless(bot, call.message)
    elif call.data == "trial_vless":
        trial_vless(bot, call.message)
# === Bagian Qallbackquerry Fungsi Menu TROJAN ===
    elif data == 'create_trojan':
        create_trojan(bot, call.message)    
    elif call.data == "delete_trojan":
        delete_trojan(bot, call.message)
    elif call.data.startswith('confirm_delete_trojan') or call.data == "cancel_delete":
        process_to_delete_trojan(bot, call)
    elif call.data == "renew_trojan":
        renew_trojan(bot, call.message)
    elif call.data == "detail_trojan":
        detail_trojan(bot, call.message)
    elif call.data == "trial_trojan":
        trial_trojan(bot, call.message)
  # === Bagian Qallbackquerry Fungsi Menu LAIN ===
    elif call.data == "info_service":
        send_status(bot, call.message)
    elif call.data == "reboot":
        reboot_system(bot, call.message)
    elif call.data == "restart_service":
        restart_all_services(call.message)
    elif call.data == "restore_data":
        make_restore(call.message)
    
        
# === MENU UTAMA ===
def menu_utama(call):
    
    info = get_server_info()

    # Format region
    region = info['country']
    if info['city'] != 'Unknown':
        region = f"{info['city']}, {info['country']}"

    status_text = f"""🖥️ *Server Information* 🖥️
─────────────────────
*OS System :* `{info['os']}`
*ISP :* `{info['isp']}`
*Region :* `{region}`
*IP :* `{info['ip']}`
*Domain :* `{info['domain']}`
*XRay Version :* `{info['version']}`

🔐 *Jumlah Akun Aktif* 🔐
*SSH* : `{info['ssh']}`
*Vmess* : `{info['vmess']}`
*Vless* : `{info['vless']}`
*Trojan* : `{info['trojan']}`
─────────────────────"""

    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
    btn_ssh = telebot.types.InlineKeyboardButton("MENU SSH", callback_data='menu_ssh')
    btn_vmess = telebot.types.InlineKeyboardButton("MENU VMESS", callback_data='menu_vmess')
    btn_vless = telebot.types.InlineKeyboardButton("MENU VLESS", callback_data='menu_vless')
    btn_trojan = telebot.types.InlineKeyboardButton("MENU TROJAN", callback_data='menu_trojan')
    btn_lain = telebot.types.InlineKeyboardButton("MENU LAIN", callback_data='menu_lain')

    markup.add(btn_ssh, btn_vmess)
    markup.add(btn_vless, btn_trojan)
    markup.add(btn_lain)
    
    bot.edit_message_text(
            chat_id=call.message.chat.id, 
            message_id=call.message.message_id,
            text=status_text,
            reply_markup=markup,
            parse_mode='Markdown'
        ) 

# === MENU SSH ===
def menu_ssh(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE SSH", callback_data='create_ssh')
    sub2 = types.InlineKeyboardButton("DELETE SSH", callback_data='delete_ssh')
    sub3 = types.InlineKeyboardButton("RENEW SSH", callback_data='renew_ssh')
    sub4 = types.InlineKeyboardButton("DETAIL SSH", callback_data='detail_ssh')
    sub5 = types.InlineKeyboardButton("TRIAL SSH", callback_data='trial_ssh')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU SSH MANAGER :: 📘
─────────────────────
• Buat Akun SSH
• Hapus Akun SSH
• Perpanjang Akun SSH
• Lihat Detail SSH
• Trial SSH
─────────────────────"""
    
    bot.edit_message_text(
            chat_id=call.message.chat.id, 
            message_id=call.message.message_id,
            text=massage_text,
            reply_markup=markup,
            parse_mode='Markdown'
        ) 
        
# === MENU VMESS ===
def menu_vmess(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE VMESS", callback_data='create_vmess')
    sub2 = types.InlineKeyboardButton("DELETE VMESS", callback_data='delete_vmess')
    sub3 = types.InlineKeyboardButton("RENEW VMESS", callback_data='renew_vmess')
    sub4 = types.InlineKeyboardButton("DETAIL VMESS", callback_data='detail_vmess')
    sub5 = types.InlineKeyboardButton("TRIAL VMESS", callback_data='trial_vmess')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU VMESS MANAGER :: 📘
─────────────────────
• Buat Akun VMESS
• Hapus Akun VMESS
• Perpanjang Akun VMESS
• Lihat Detail VMESS
• Trial VMESS
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    )        
        
# === MENU VLESS ===
def menu_vless(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE VLESS", callback_data='create_vless')
    sub2 = types.InlineKeyboardButton("DELETE VLESS", callback_data='delete_vless')
    sub3 = types.InlineKeyboardButton("RENEW VLESS", callback_data='renew_vless')
    sub4 = types.InlineKeyboardButton("DETAIL VLESS", callback_data='detail_vless')
    sub5 = types.InlineKeyboardButton("TRIAL VLESS", callback_data='trial_vless')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU VLESS MANAGER :: 📘
─────────────────────
• Buat Akun VLESS
• Hapus Akun VLESS
• Perpanjang Akun VLESS
• Lihat Detail VLESS
• Trial VLESS
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    )    
    
# === MENU TROJAN ===
def menu_trojan(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE TROJAN", callback_data='create_trojan')
    sub2 = types.InlineKeyboardButton("DELETE TROJAN", callback_data='delete_trojan')
    sub3 = types.InlineKeyboardButton("RENEW TROJAN", callback_data='renew_trojan')
    sub4 = types.InlineKeyboardButton("DETAIL TROJAN", callback_data='detail_trojan')
    sub5 = types.InlineKeyboardButton("TRIAL TROJAN", callback_data='trial_trojan')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU TROJAN MANAGER :: 📘
─────────────────────
• Buat Akun TROJAN
• Hapus Akun TROJAN
• Perpanjang Akun TROJAN
• Lihat Detail TROJAN
• Trial TROJAN
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    ) 
    
# === MENU LAIN ===
def menu_lain(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("SERVICE INFO", callback_data='info_service')
    sub2 = types.InlineKeyboardButton("RESTART SERVICE", callback_data='restart_service')
    sub3 = types.InlineKeyboardButton("RESTORE DATA", callback_data='restore_data')
    sub4 = types.InlineKeyboardButton("REBOOT", callback_data='reboot')
    sub5 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
  
    markup.add(sub1, sub2, sub3, sub4)
    markup.add(sub5)
    
    massage_text = """📘 :: MENU LAIN :: 📘
─────────────────────
• System service 
• Restart service 
• Restore Data
• Reboot
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    )    

# === Fungsi Restore ===

# Status aktivasi restore
restore_active = False

def restore_backup(zip_filepath):
    """Fungsi utama untuk melakukan restore"""
    try:
        # Ekstrak file zip
        with zipfile.ZipFile(zip_filepath, 'r') as zip_ref:
            zip_ref.extractall("/tmp/restore")

        # Restore file sistem
        for file in ["passwd", "group", "shadow", "gshadow"]:
            shutil.copy2(os.path.join("/tmp/restore", file), "/etc/")

        # Restore folder xray
        xray_src = os.path.join("/tmp/restore", "xray")
        xray_dest = os.path.join("/etc/", "xray")
        
        if os.path.exists(xray_dest):
            shutil.rmtree(xray_dest)
        shutil.copytree(xray_src, xray_dest)

        # Bersihkan temporary files
        shutil.rmtree("/tmp/restore")
        return True
    except Exception as e:
        print(f"Restore error: {e}")
        return False

def make_restore(message):
    """Aktivasi mode restore"""
    global restore_active
    restore_active = True
    bot.reply_to(message, "🔓 Mode restore diaktifkan. Silakan upload file backup ZIP sekarang.\n"
                         "⚠️ File akan langsung diproses!")

@bot.message_handler(content_types=['document'])
def handle_docs(message):
    """Handler untuk file backup"""
    global restore_active
    
    if not restore_active:
        bot.reply_to(message, "🔒 Mode restore belum aktif. Kirim /restore terlebih dahulu.")
        return

    try:
        # Download file
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)

        # Simpan sementara
        zip_path = f"/tmp/{message.document.file_name}"
        with open(zip_path, 'wb') as f:
            f.write(downloaded_file)

        # Proses restore
        if restore_backup(zip_path):
            bot.reply_to(message, "✅ Restore berhasil!\n"
                                "➡️ Lakukan restart service dan update domain jika diperlukan")
        else:
            bot.reply_to(message, "❌ Gagal melakukan restore. Format file tidak valid.")

        # Bersihkan dan nonaktifkan mode
        os.remove(zip_path)
        restore_active = False

    except Exception as e:
        restore_active = False
        bot.reply_to(message, f"⚠️ Error: {str(e)}")
        if os.path.exists(zip_path):
            os.remove(zip_path)

# RESTART SERVICE

# List of services to restart
SERVICES = ["nginx", "dropbear", "ws-service", "auto"]

def restart_single_service(service_name, message):
    chat_id = message.chat.id
    msg = bot.send_message(chat_id, f"Restarting {service_name}...")
    
    # Animation dots
    for i in range(3):
        try:
            bot.edit_message_text(f"Restarting {service_name}{'.'*(i+1)}", 
                                chat_id=chat_id, 
                                message_id=msg.message_id)
            time.sleep(0.5)
        except:
            pass
    
    # Execute restart command
    try:
        subprocess.run(['systemctl', 'restart', service_name], 
                      check=True, 
                      stdout=subprocess.PIPE, 
                      stderr=subprocess.PIPE)
        status = "✅ Success"
    except subprocess.CalledProcessError:
        status = "❌ Failed"
    
    # Update final status
    try:
        bot.edit_message_text(f"Restart {service_name} - {status}", 
                            chat_id=chat_id, 
                            message_id=msg.message_id)
    except:
        pass

def restart_all_services(message):
    # Send initial message
    bot.send_message(message.chat.id, "🚀 Starting to restart all services...")
    
    # Restart each service in sequence
    for service in SERVICES:
        restart_single_service(service, message)
        time.sleep(1)  # Small delay between services
    
    # Completion message
    bot.send_message(message.chat.id, "✨ All services have been restarted!")



# === Jalankan Bot ===
bot_online()
print("Bot sedang berjalan...")
bot.polling(none_stop=True)