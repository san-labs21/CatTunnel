import telebot
import subprocess
import os
from telebot import types

def get_valid_users():
    """Get list of valid SSH users"""
    try:
        result = subprocess.run(["getent", "passwd"], capture_output=True, text=True)
        users = []
        for line in result.stdout.splitlines():
            parts = line.split(':')
            if int(parts[2]) >= 1000 and int(parts[2]) != 65534:
                users.append(parts[0])
        return users
    except Exception as e:
        print(f"Error getting users: {e}")
        return []


def delete_ssh(bot, message):
    """Handle the delete SSH account command"""
    users = get_valid_users()
    if not users:
        bot.reply_to(message, "No valid SSH users found.")
        return
    
    # Create the user list message
    user_list = "┌──────────────────┐\n"
    user_list += "   .:: DELETE SSH ACCOUNT ::.    \n"
    user_list += "└──────────────────┘\n"

    for i, user in enumerate(users, 1):
        user_list += f"  {i:2}. {user:17}\n"
            
    user_list += "└──────────────────┘\n"
    user_list += "Input number user to select!!"
    
    # Send the user list
    msg = bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=user_list
            ) 
    
    # Register the next step handler
    bot.register_next_step_handler(msg, process_user_selection, users, bot)

def process_user_selection(message, users, bot):
    """Process the user selection"""
    try:
        num = int(message.text)
        if 1 <= num <= len(users):
            username = users[num-1]
            # Create inline keyboard for confirmation
            markup = types.InlineKeyboardMarkup()
            yes_btn = types.InlineKeyboardButton("✅ Yes", callback_data=f"confirm_yes_{username}")
            no_btn = types.InlineKeyboardButton("❌ No", callback_data=f"confirm_no_{username}")
            markup.row(yes_btn, no_btn)
            
            bot.send_message(message.chat.id,
                           f"You selected to delete: {username}\n"
                           "Are you sure?",
                           reply_markup=markup)
        else:
            bot.reply_to(message, "Invalid number. Please try again.")
    except ValueError:
        bot.reply_to(message, "Please enter a valid number.")


def handle_confirmation(bot, call):
    """Handle the confirmation button clicks"""
    username = call.data.split('_')[-1]  # Extract username from callback data
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    if call.data.startswith('confirm_yes'):
        try:
            # Delete the user
            result = subprocess.run(["userdel", "-r", username], capture_output=True, text=True)
            # delete file history
            filename = f'ssh-{username}'
            filepath = os.path.join("/etc/xray/history/", filename)
            os.remove(filepath)

            if result.returncode == 0:
                success_msg = (
                    "   ✅   Berhasil Menghapus    \n"
                    "───────────────────\n"
                    f"User   : {username}\n"
                    "───────────────────"
                )
                bot.edit_message_text(chat_id=call.message.chat.id,
                                    message_id=call.message.message_id,
                                    text=success_msg, reply_markup=markup)
            else:
                bot.answer_callback_query(call.id, f"Failed to delete account {username}")
        except Exception as e:
            bot.answer_callback_query(call.id, f"Error deleting user: {e}")
    elif call.data.startswith('confirm_no'):
        bot.edit_message_text(chat_id=call.message.chat.id,
                            message_id=call.message.message_id,
                            text=f"Deletion canceled for user {username}")
    
    # Answer the callback query to remove the loading animation
    bot.answer_callback_query(call.id)