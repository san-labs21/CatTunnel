import telebot
import subprocess
from datetime import datetime

# Fungsi untuk cek status service
def check_service(service_name):
    try:
        status = subprocess.run(['systemctl', 'is-active', service_name], 
                               capture_output=True, text=True)
        if status.stdout.strip() == 'active':
            return f"🟢  {service_name} : Aktif"
        else:
            return f"🔴  {service_name} : Tidak Aktif"
    except:
        return f"⚪  {service_name} : Tidak Diketahui"

def send_status(bot, message):
    # Header
    response = "┌─────────────────────┐\n"
    response += "     🔍 STATUS LAYANAN VPS    \n"
    response += "└────────────────────┘\n\n"
    
    # Cek status layanan penting
    services = [
        "xray.service",
        "nginx",
        "ws-service.service",
        "auto.service",
        "dropbear"
    ]
    
    for service in services:
        response += check_service(service) + "\n"
    
    # Footer
    response += "\n"
    
    # Get uptime
    uptime = subprocess.run(['uptime', '-p'], capture_output=True, text=True)
    uptime_str = uptime.stdout.strip().replace('up ', '') if uptime.stdout else "Tidak diketahui"
    
    response += f"📌 Uptime Sistem: {uptime_str}\n"
    response += f"📅 Waktu Sekarang: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
    response += "-------------------------------\n"
    response += "✔️ Selesai memeriksa layanan."
    
    
    bot.send_message(message.chat.id, response)

def reboot_system(bot, message):
    bot.reply_to(message, "⚠️  Sistem akan reboot dalam 5 detik...")
    subprocess.run(['sleep', '5'])
    subprocess.run(['reboot'])
