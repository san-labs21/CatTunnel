import telebot
import json
import os
import re
from telebot import types


# Config file paths
CONFIG_FILE = '/etc/xray/config.json'
LIMIT_FILE = '/etc/xray/limitip/clients_limit.conf'

def get_users_list_vless():
    users = []
    seen_users = set()
    
    try:
        with open(CONFIG_FILE, 'r') as f:
            lines = f.readlines()
            
        for i in range(len(lines)):
            line = lines[i].strip()
            if line.startswith('#?'):
                parts = line.split()
                if len(parts) >= 3:
                    user = parts[1]
                    expired = parts[2]
                    if user not in seen_users:
                        seen_users.add(user)
                        users.append({'user': user, 'expired': expired})
    except Exception as e:
        print(f"Error reading config file: {e}")
    
    return users

def delete_user_vless(username):
    try:
        # Backup config file
        os.system(f'cp {CONFIG_FILE} {CONFIG_FILE}.bak')
        
        # Remove from config.json
        with open(CONFIG_FILE, 'r') as f:
            lines = f.readlines()
        
        new_lines = []
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith(f'#? {username} '):
                # Skip this line and the next one
                i += 2
                continue
            new_lines.append(lines[i])
            i += 1
        
        with open(CONFIG_FILE, 'w') as f:
            f.writelines(new_lines)
        
        # Remove from limit file if exists
        if os.path.exists(LIMIT_FILE):
            with open(LIMIT_FILE, 'r') as f:
                lines = f.readlines()
            
            with open(LIMIT_FILE, 'w') as f:
                for line in lines:
                    if not line.strip().startswith(username):
                        f.write(line)
        
        # Restart xray service
        os.system('systemctl restart xray')
        return True
    except Exception as e:
        print(f"Error deleting user: {e}")
        return False


def delete_vless(bot, message):
    users = get_users_list_vless()
    if not users:
        bot.reply_to(message, "No users found to delete!")
        return
    
    # Create numbered list
    response = "┌──────────────────┐\n"
    response += "  .:: DELETE VLESS ACCOUNT ::.   \n"
    response += "└──────────────────┘\n"
    
    for idx, user in enumerate(users, 1):
        response += f" {idx:4}. {user['user'][:19]:19}\n"
    response += "└──────────────────┘\n"
    response += "Input user number to select!"
    
    # Send the list and register next handler
    msg = bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=response,
                  parse_mode='HTML') 

    bot.register_next_step_handler(msg, process_delete_choice_vless, users, bot)

def process_delete_choice_vless(message, users, bot):
    try:
        # Get the number from user's message
        choice = int(message.text.strip())
        
        # Validate choice
        if choice < 1 or choice > len(users):
            bot.reply_to(message, "Invalid number. Please try again.")
            return
            
        # Get the selected user
        selected_user = users[choice-1]
        
        # Create confirmation buttons
        markup = types.InlineKeyboardMarkup()
        btn_yes = types.InlineKeyboardButton("✅ Yes", callback_data=f"confirm_delete_vless:{selected_user['user']}")
        btn_no = types.InlineKeyboardButton("❌ No", callback_data="cancel_delete")
        markup.row(btn_yes, btn_no)
        
        bot.send_message(
            message.chat.id,
            f"⚠️ Are you sure you want to delete user:\n\nUsername: <code>{selected_user['user']}</code>\nExpired: <code>{selected_user['expired']}</code>",
            parse_mode='HTML',
            reply_markup=markup
        )
        
    except ValueError:
        bot.reply_to(message, "Please enter a valid number.")
    except Exception as e:
        bot.reply_to(message, f"An error occurred: {e}")


def delete_confirm_vless(bot, call):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    if call.data.startswith("confirm_delete_vless:"):
        username = call.data.split(":")[1]
        if delete_user_vless(username):
            # delete file history
            filename = f'vless-{username}'
            filepath = os.path.join("/etc/xray/history/", filename)
            os.remove(filepath)

            bot.answer_callback_query(call.id, "User deleted successfully!")
            success_msg = (
                    "   ✅   Berhasil Menghapus    \n"
                    "───────────────────\n"
                    f"User   : {username}\n"
                    "───────────────────")

            bot.edit_message_text(
                  chat_id=call.message.chat.id,
                  message_id=call.message.message_id,
                  text=success_msg,
                  reply_markup=markup,
                  parse_mode='HTML') 
        else:
            bot.answer_callback_query(call.id, "Failed to delete user!")
            bot.edit_message_text(
                f"❌ Failed to delete user <code>{username}</code>.",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML'
            )
    elif call.data == "cancel_delete":
        bot.answer_callback_query(call.id, "Deletion cancelled")
        bot.edit_message_text(
            "❌ User deletion cancelled.",
            call.message.chat.id,
            call.message.message_id
        )