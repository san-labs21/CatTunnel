import telebot
import re
from datetime import datetime, timedelta
import json
import os
from telebot import types


# Path to your Xray config file
CONFIG_FILE = '/etc/xray/config.json'
BACKUP_FILE = '/etc/xray/config.json.bak'


def renew_vless(bot, message):
    try:
        with open(CONFIG_FILE, 'r') as f:
            config_data = f.read()
        
        # Find all VLESS user entries with pattern #? username tanggalxp
        user_entries = re.findall(r'#\?\s+(\S+)\s+(\d{4}-\d{2}-\d{2})', config_data)
        
        if not user_entries:
            bot.send_message(message.chat.id, "❌ Tidak ada user VLESS yang ditemukan!")
            return
        
        # Get unique users
        seen_users = {}
        unique_users = []
        for user, expired in user_entries:
            if user not in seen_users:
                seen_users[user] = expired
                unique_users.append((user, expired))
        
        # Create user list message
        response = "┌──────────────────┐\n"
        response += "  .:: RENEW VLESS ACCOUNT ::. \n"
        response += "└──────────────────┘\n"
        for i, (user, expired) in enumerate(unique_users, start=1):
           response += f"  {i}. {user} | <b>{expired}</b>\n"
        response +="└──────────────────┘\n"
        response += "Input user number to select!"
        
        msg = bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=response,
                  parse_mode='HTML') 
        
        # Register next step handler
        bot.register_next_step_handler(msg, process_user_selection, unique_users, bot)
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Error: {str(e)}")

def process_user_selection(message, user_list, bot):
    try:
        chat_id = message.chat.id
        
        try:
            choice = int(message.text)
            if choice < 1 or choice > len(user_list):
                bot.send_message(chat_id, "❌ Nomor tidak valid!")
                return
            
            selected_user, current_expired = user_list[choice - 1]
            
            msg = bot.send_message(chat_id, f"🔹 User : {selected_user}\n"
                                    f"📅 Masa Aktif Saat Ini : {current_expired}\n\n"
                                    "Berapa hari ingin ditambahkan?")
            
            # Register next step handler
            bot.register_next_step_handler(msg, process_days_addition, selected_user, current_expired, bot)
            
        except ValueError:
            bot.send_message(chat_id, "❌ Harap masukkan nomor yang valid!")
    
    except Exception as e:
        bot.send_message(chat_id, f"❌ Error: {str(e)}")

def process_days_addition(message, selected_user, current_expired, bot):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    try:
        chat_id = message.chat.id
        
        try:
            days_to_add = int(message.text)
            if days_to_add <= 0:
                bot.send_message(chat_id, "❌ Jumlah hari harus lebih dari 0!")
                return
            
            # Calculate new expired date
            current_date = datetime.strptime(current_expired, '%Y-%m-%d')
            new_date = current_date + timedelta(days=days_to_add)
            new_expired = new_date.strftime('%Y-%m-%d')
            
            # Backup config file
            os.system(f'cp {CONFIG_FILE} {BACKUP_FILE}')
            
            # Update config file
            with open(CONFIG_FILE, 'r') as f:
                config_data = f.read()
            
            # Replace all occurrences of the user's expired date with VLESS pattern
            updated_config = re.sub(
                fr'(#\?\s+{re.escape(selected_user)}\s+){re.escape(current_expired)}',
                fr'\g<1>{new_expired}',
                config_data
            )
            
            with open(CONFIG_FILE, 'w') as f:
                f.write(updated_config)
            
            # Send success message
            bot.send_message(chat_id, f"✅ Berhasil Diperbarui!\n\n"
                                    f"👤 User : {selected_user}\n"
                                    f"📅 Masa Aktif Sekarang : {new_expired}", reply_markup=markup)
                
        except ValueError:
            bot.send_message(chat_id, "❌ Harap masukkan jumlah hari yang valid (angka)!")
    
    except Exception as e:
        bot.send_message(chat_id, f"❌ Error: {str(e)}")