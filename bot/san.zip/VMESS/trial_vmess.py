import telebot
import uuid
import json
import base64
import subprocess
import random
import string
from telebot import types
from datetime import datetime, timedelta


def generate_random_text(length=8):
    """Generate random text for trial username"""
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(length))

def is_positive_integer(value):
    try:
        num = int(value)
        return num > 0
    except ValueError:
        return False

def build_vmess(user, host, uuid, proto):
    config = {
        "v": "2",
        "ps": f"{user}-{proto}",
        "add": host,
        "port": "443" if proto in ["TLS", "gRPC"] else "80",
        "id": uuid,
        "aid": "0",
        "net": "ws" if proto in ["TLS", "WS"] else "grpc",
        "type": "none" if proto in ["TLS", "WS"] else "gun",
        "host": host,
        "path": "/vmess" if proto in ["TLS", "WS"] else "/vmess-grpc",
        "tls": "tls" if proto in ["TLS", "gRPC"] else "",
        "sni": host if proto in ["TLS", "gRPC"] else ""
    }
    return base64.b64encode(json.dumps(config).encode()).decode()

def add_to_config(user, uuid, days):
    today = datetime.now().strftime("%Y-%m-%d")
    exp_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
    new_entry = f'{{"id": "{uuid}", "alterId": 0, "email": "{user}"}},'
    comment_line = f"## {user} {exp_date}"
    
    config_file = "/etc/xray/config.json"
    
    # Create a temporary file with the new content
    temp_content = f"{comment_line}\n{new_entry}\n"
    
    # Add to VMESS section
    subprocess.run([
        'sed', '-i',
        r'/\/\/ VMESS$/r /dev/stdin',
        config_file
    ], input=temp_content.encode())
    
    # Add to VMESS-GRPC section
    subprocess.run([
        'sed', '-i',
        r'/\/\/ VMESS-GRPC$/r /dev/stdin',
        config_file
    ], input=temp_content.encode())
    
    return exp_date

def set_ip_limit(user, limit):
    limit_file = "/etc/xray/limitip/clients_limit.conf"
    with open(limit_file, 'a') as f:
        f.write(f"{user}={limit}\n")

def trial_vmess(bot, message):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    try:
        # Generate trial username
        random_text = generate_random_text()
        user = f"Trial-{random_text}"
        days = 1  # Fixed 1-day expiration for trial
        limit = 1  # Fixed 1 IP limit for trial
        
        # Generate UUID
        new_uuid = str(uuid.uuid4())
        
        # Get host
        with open('/etc/xray/domain', 'r') as f:
            host = f.read().strip()
        
        # Add to config
        exp_date = add_to_config(user, new_uuid, days)
        
        # Set IP limit
        set_ip_limit(user, limit)
        
        # Generate links
        link_tls = build_vmess(user, host, new_uuid, "TLS")
        link_ws = build_vmess(user, host, new_uuid, "WS")
        link_grpc = build_vmess(user, host, new_uuid, "gRPC")
        
        # Save to history
        history_file = f"/etc/xray/history/vmess-{user}"
        history_content = f"""✅ Trial VMess Account Berhasil Dibuat
Username     : {user}
Expired      : {exp_date}
Limit IP     : {limit}
-----------------------------------------------
UUID: {new_uuid}
Host: {host}
-----------------------------------------------
1. WebSocket + TLS (Port 443)
vmess://{link_tls}

2. WebSocket (tanpa TLS, Port 80)
vmess://{link_ws}

3. gRPC (Port 443)
vmess://{link_grpc}
-----------------------------------------------"""
        
        subprocess.run(['mkdir', '-p', '/etc/xray/history'])
        with open(history_file, 'w') as f:
            f.write(history_content)
        
        # Restart xray
        subprocess.run(['systemctl', 'restart', 'xray'])
        
        # Send results to user
        result_message = f"""🎟️ Trial VMess Account Berhasil Dibuat
Username    : {user}
Expired     : {exp_date} (1 hari)
Limit IP    : {limit}
-----------------------------------------------
UUID: <code>{new_uuid}</code>
Host: {host}
-----------------------------------------------
1. WebSocket + TLS (Port 443)
<code>vmess://{link_tls}</code>

2. WebSocket (tanpa TLS, Port 80)
<code>vmess://{link_ws}</code>

3. gRPC (Port 443)
<code>vmess://{link_grpc}</code>
-----------------------------------------------
⚠️ Akun trial hanya berlaku 1 hari dan limit 1 IP"""
        
        bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=result_message,
                  reply_markup=markup,
                  parse_mode='HTML') 
        
    except Exception as e:
        bot.reply_to(message, f'Error: {str(e)}')
