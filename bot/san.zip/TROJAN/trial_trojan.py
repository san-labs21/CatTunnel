import telebot
import uuid
import os
from datetime import datetime, timedelta
import subprocess
from telebot import types
import string
import random

def generate_random_text(length=8):
    """Generate random text for trial username"""
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(length))

def trial_trojan(bot, message):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    chat_id = message.chat.id
    random_text = generate_random_text()
    username = f"Trial-{random_text}"
    days_active = 1
    ip_limit = 1

    try:
        # Generate UUID
        new_uuid = str(uuid.uuid4()).lower()
        
        # Hitung tanggal expired
        current_date = datetime.now()
        exp_date = current_date + timedelta(days=days_active)
        exp_date_str = exp_date.strftime("%Y-%m-%d")
        
        # Baca host dari file
        with open('/etc/xray/domain', 'r') as f:
            host = f.read().strip()
        
        # Tambahkan ke file limit IP
        limit_ip_file = "/etc/xray/limitip/clients_limit.conf"
        with open(limit_ip_file, 'a') as f:
            f.write(f"{username}={ip_limit}\n")
        
        # Tambahkan ke config.json
        config_file = "/etc/xray/config.json"
        new_entry = f'{{"password": "{new_uuid}", "email": "{username}"}},'
        comment_line = f"#! {username} {exp_date_str}"
        
        # Update config.json untuk Trojan (WS dan gRPC)
        with open(config_file, 'r') as f:
            content = f.readlines()
        
        # Proses modifikasi konten
        new_content = []
        trojan_modified = False
        trojan_grpc_modified = False
        
        for line in content:
            new_content.append(line)
            
            # Sisipkan setelah // TROJAN
            if "// TROJAN" in line and not trojan_modified:
                new_content.append(f"{comment_line}\n")
                new_content.append(f"{new_entry}\n")
                trojan_modified = True
                
            # Sisipkan setelah // TROJAN-GRPC
            if "// TROJAN-GRPC" in line and not trojan_grpc_modified:
                new_content.append(f"{comment_line}\n")
                new_content.append(f"{new_entry}\n")
                trojan_grpc_modified = True
        
        with open(config_file, 'w') as f:
            f.writelines(new_content)
        
        # Buat link Trojan
        port = 443
        security = "tls"
        
        # WebSocket + TLS
        path_ws = "/trojan-ws"
        link_ws = f"trojan://{new_uuid}@{host}:{port}?type=ws&host={host}&path={path_ws}&security={security}&sni={host}#{username}-TLS"
        
        # gRPC
        path_grpc = "/trojan-grpc"
        link_grpc = f"trojan://{new_uuid}@{host}:{port}?type=grpc&host={host}&serviceName={path_grpc}&security={security}&sni={host}#{username}-gRPC"
        
        # Simpan history
        history_dir = "/etc/xray/history"
        if not os.path.exists(history_dir):
            os.makedirs(history_dir)
            
        history_file = f"{history_dir}/trojan-{username}"
        with open(history_file, 'w') as f:
            f.write(f"✅ Account Trojan Berhasil Dibuat\n")
            f.write(f"Username     : {username}\n")
            f.write(f"Expired      : {exp_date_str}\n")
            f.write(f"Limit IP     : {ip_limit}\n")
            f.write("-----------------------------------------------\n")
            f.write(f"UUID         : {new_uuid}\n")
            f.write(f"Host/SNI     : {host}\n")
            f.write(f"Port         : {port}\n")
            f.write("-----------------------------------------------\n")
            f.write("1. WebSocket + TLS\n")
            f.write(f"{link_ws}\n\n")
            f.write("2. gRPC\n")
            f.write(f"{link_grpc}\n")
            f.write("-----------------------------------------------\n")
        
        # Restart xray
        subprocess.run(["systemctl", "restart", "xray"], check=True)
        
        # Kirim hasil ke pengguna
        response = (
            f"✅ Account Trojan Berhasil Dibuat\n"
            f"Username     : {username}\n"
            f"Expired      : {exp_date_str}\n"
            f"Limit IP     : {ip_limit}\n"
            f"-----------------------------------------------\n"
            f"UUID         : {new_uuid}\n"
            f"Host/SNI     : {host}\n"
            f"Port         : {port}\n"
            f"-----------------------------------------------\n"
            f"1. WebSocket + TLS\n"
            f"<code>{link_ws}</code>\n\n"
            f"2. gRPC\n"
            f"<code>{link_grpc}</code>\n"
            f"-----------------------------------------------"
        )
        
        
        bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=response,
                  reply_markup=markup,
                  parse_mode='HTML') 
        
    except subprocess.CalledProcessError as e:
        bot.send_message(chat_id, f"Gagal restart Xray: {str(e)}")
    except FileNotFoundError as e:
        bot.send_message(chat_id, f"File tidak ditemukan: {str(e)}")
    except Exception as e:
        bot.send_message(chat_id, f"Terjadi error saat membuat akun: {str(e)}")