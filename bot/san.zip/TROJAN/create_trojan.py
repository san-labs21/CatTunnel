import telebot
import uuid
import os
import random
import string
from datetime import datetime, timedelta
import subprocess
from telebot import types


def generate_random_suffix(length=4):
    """Generate a random alphanumeric suffix"""
    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def check_username_exists(username):
    """Check if username already exists in config"""
    config_file = "/etc/xray/config.json"
    try:
        with open(config_file, 'r') as f:
            content = f.read()
            return f'"email": "{username.lower()}"' in content
    except FileNotFoundError:
        return False

def create_trojan(bot, message):
    msg = bot.send_message(message.chat.id, "Input Username!")
    bot.register_next_step_handler(msg, process_username_step, bot)

def process_username_step(message, bot):
    try:
        username = message.text.strip()
        
        # Validasi username
        if not username or ' ' in username:
            bot.reply_to(message, "Username tidak valid. Harus tanpa spasi.")
            return
            
        # Check if username exists and add random suffix if needed
        if check_username_exists(username):
            random_suffix = generate_random_suffix()
            modified_username = f"{username}-{random_suffix}"
            bot.send_message(message.chat.id, f"Username sudah ada! Menambahkan suffix acak: {modified_username}")
            username = modified_username
            
        msg = bot.send_message(message.chat.id, "Input expired days!")
        bot.register_next_step_handler(msg, process_days_step, username, bot)
    except Exception as e:
        bot.reply_to(message, f"Terjadi error: {str(e)}")

def process_days_step(message, username, bot):
    try:
        days = message.text.strip()
        
        # Validasi input hari
        if not days.isdigit() or int(days) <= 0:
            bot.reply_to(message, "Input harus berupa angka positif.")
            return
            
        msg = bot.send_message(message.chat.id, "Limit IP!")
        bot.register_next_step_handler(msg, process_ip_limit_step, username, int(days), bot)
    except Exception as e:
        bot.reply_to(message, f"Terjadi error: {str(e)}")

def process_ip_limit_step(message, username, days_active, bot):
    try:
        ip_limit = message.text.strip()
        
        # Validasi input IP limit
        if not ip_limit.isdigit() or int(ip_limit) <= 0:
            bot.reply_to(message, "Limit IP harus berupa angka positif.")
            return
            
        # Proses pembuatan akun
        create_trojan_account(message.chat.id, username, days_active, int(ip_limit), bot)
    except Exception as e:
        bot.reply_to(message, f"Terjadi error: {str(e)}")

def create_trojan_account(chat_id, username, days_active, ip_limit, bot):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    markup.add(sub1)

    try:
        # Generate UUID
        new_uuid = str(uuid.uuid4()).lower()
        
        # Hitung tanggal expired
        current_date = datetime.now()
        exp_date = current_date + timedelta(days=days_active)
        exp_date_str = exp_date.strftime("%Y-%m-%d")
        
        # Baca host dari file
        with open('/etc/xray/domain', 'r') as f:
            host = f.read().strip()
        
        # Tambahkan ke file limit IP (gunakan lowercase untuk konsistensi)
        limit_ip_file = "/etc/xray/limitip/clients_limit.conf"
        with open(limit_ip_file, 'a') as f:
            f.write(f"{username.lower()}={ip_limit}\n")
        
        # Tambahkan ke config.json (gunakan lowercase untuk email/username)
        config_file = "/etc/xray/config.json"
        new_entry = f'{{"password": "{new_uuid}", "email": "{username.lower()}"}},'
        comment_line = f"#! {username.lower()} {exp_date_str}"
        
        # Backup config file
        subprocess.run(['cp', config_file, f"{config_file}.bak"], check=True)
        
        try:
            # Update config.json untuk Trojan (WS dan gRPC)
            with open(config_file, 'r') as f:
                content = f.readlines()
            
            # Proses modifikasi konten
            new_content = []
            trojan_modified = False
            trojan_grpc_modified = False
            
            for line in content:
                new_content.append(line)
                
                # Sisipkan setelah // TROJAN
                if "// TROJAN" in line and not trojan_modified:
                    new_content.append(f"{comment_line}\n")
                    new_content.append(f"{new_entry}\n")
                    trojan_modified = True
                    
                # Sisipkan setelah // TROJAN-GRPC
                if "// TROJAN-GRPC" in line and not trojan_grpc_modified:
                    new_content.append(f"{comment_line}\n")
                    new_content.append(f"{new_entry}\n")
                    trojan_grpc_modified = True
            
            with open(config_file, 'w') as f:
                f.writelines(new_content)
        except Exception as e:
            # Restore backup if error occurs
            subprocess.run(['cp', f"{config_file}.bak", config_file], check=True)
            raise e
        
        # Buat link Trojan
        port = 443
        security = "tls"
        
        # WebSocket + TLS
        path_ws = "/trojan-ws"
        link_ws = f"trojan://{new_uuid}@{host}:{port}?type=ws&host={host}&path={path_ws}&security={security}&sni={host}#{username}-TLS"
        
        # gRPC
        path_grpc = "/trojan-grpc"
        link_grpc = f"trojan://{new_uuid}@{host}:{port}?type=grpc&host={host}&serviceName={path_grpc}&security={security}&sni={host}#{username}-gRPC"
        
        # Simpan history (gunakan lowercase untuk nama file)
        history_dir = "/etc/xray/history"
        if not os.path.exists(history_dir):
            os.makedirs(history_dir)
            
        history_file = f"{history_dir}/trojan-{username.lower()}"
        with open(history_file, 'w') as f:
            f.write(f"✅ Account Trojan Berhasil Dibuat\n")
            f.write(f"Username     : {username}\n")
            f.write(f"Expired      : {exp_date_str}\n")
            f.write(f"Limit IP     : {ip_limit}\n")
            f.write("-----------------------------------------------\n")
            f.write(f"UUID         : {new_uuid}\n")
            f.write(f"Host/SNI     : {host}\n")
            f.write(f"Port         : {port}\n")
            f.write("-----------------------------------------------\n")
            f.write("1. WebSocket + TLS\n")
            f.write(f"{link_ws}\n\n")
            f.write("2. gRPC\n")
            f.write(f"{link_grpc}\n")
            f.write("-----------------------------------------------\n")
        
        # Restart xray
        subprocess.run(["systemctl", "restart", "xray"], check=True)
        
        # Kirim hasil ke pengguna
        response = (
            f"✅ Account Trojan Berhasil Dibuat\n"
            f"Username     : {username}\n"
            f"Expired      : {exp_date_str}\n"
            f"Limit IP     : {ip_limit}\n"
            f"-----------------------------------------------\n"
            f"UUID         : <code>{new_uuid}</code>\n"
            f"Host/SNI     : {host}\n"
            f"Port         : {port}\n"
            f"-----------------------------------------------\n"
            f"1. WebSocket + TLS\n"
            f"<code>{link_ws}</code>\n\n"
            f"2. gRPC\n"
            f"<code>{link_grpc}</code>\n"
            f"-----------------------------------------------"
        )
        
        bot.send_message(chat_id, response, reply_markup=markup, parse_mode='HTML')
        
    except subprocess.CalledProcessError as e:
        bot.send_message(chat_id, f"Gagal restart Xray: {str(e)}")
    except FileNotFoundError as e:
        bot.send_message(chat_id, f"File tidak ditemukan: {str(e)}")
    except Exception as e:
        bot.send_message(chat_id, f"Terjadi error saat membuat akun: {str(e)}")